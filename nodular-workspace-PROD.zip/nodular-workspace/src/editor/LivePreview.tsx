import { useWorkflowStore } from '../store/useWorkflowStore'
export default function LivePreview() {
  const { previewHtml } = useWorkflowStore()
  return (
    <div style={{ height: '100%', background: '#fff', color: '#000', overflow: 'auto' }}>
      <div style={{ padding: '8px 12px', background: '#f5f5f5', borderBottom: '1px solid #ddd', fontSize: 11, display: 'flex', justifyContent: 'space-between' }}>
        <span>HTML / React Preview</span><button style={{ fontSize: 10, padding: '2px 6px' }}>Run Workflow</button>
      </div>
      <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
    </div>
  )
}
