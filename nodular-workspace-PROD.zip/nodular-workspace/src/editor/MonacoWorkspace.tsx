import Editor from '@monaco-editor/react'
import { useWorkflowStore } from '../store/useWorkflowStore'

export default function MonacoWorkspace() {
  const { code, agentSuggestion, setCode } = useWorkflowStore()
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0e0e0e', borderLeft: '1px solid #222' }}>
      <div style={{ padding: '10px 12px', fontSize: 12, borderBottom: '1px solid #222', display: 'flex', justifyContent: 'space-between' }}>
        <span>REA • Live Code Editor</span><span style={{ color: '#22c55e' }}>● streaming</span>
      </div>
      <div style={{ padding: 8, background: '#1a1a1a', fontSize: 11, color: '#a78bfa', borderBottom: '1px solid #222' }}>{agentSuggestion}</div>
      <Editor height="100%" defaultLanguage="typescript" theme="vs-dark" value={code} onChange={(v)=>setCode(v||'')} options={{ minimap: { enabled: false }, fontSize: 12 }} />
    </div>
  )
}
