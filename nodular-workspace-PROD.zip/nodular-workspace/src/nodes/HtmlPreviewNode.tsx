import { Handle, Position, NodeProps } from '@xyflow/react'
export function HtmlPreviewNode({ data }: NodeProps) {
  return (
    <div style={{ width: 300, background: '#111', border: '1px solid #333', borderRadius: 12, padding: 12 }}>
      <div style={{ fontSize: 11, color: '#888' }}>OUTPUT • React / HTML Live</div>
      <div style={{ marginTop: 8, borderRadius: 8, overflow: 'hidden', background: '#fff' }}>
        <div dangerouslySetInnerHTML={{ __html: (data as any).html }} />
      </div>
      <Handle type="target" position={Position.Left} />
    </div>
  )
}
