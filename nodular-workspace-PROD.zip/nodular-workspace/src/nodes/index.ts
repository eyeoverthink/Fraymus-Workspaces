import { FluxNode } from './FluxNode'
import { LlamaNode } from './LlamaNode'
import { HtmlPreviewNode } from './HtmlPreviewNode'
export const nodeTypes = { flux: FluxNode, llama: LlamaNode, htmlPreview: HtmlPreviewNode }
