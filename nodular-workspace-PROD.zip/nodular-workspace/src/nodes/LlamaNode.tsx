import { Handle, Position, NodeProps } from '@xyflow/react'
export function LlamaNode({ data, selected }: NodeProps) {
  return (
    <div style={{ width: 280, background: selected ? '#1a1a1a' : '#111', border: `1px solid ${selected ? '#a78bfa' : '#333'}`, borderRadius: 12, padding: 12 }}>
      <div style={{ fontSize: 11, color: '#a78bfa', marginBottom: 8 }}>BRAIN • Groq Llama 3.3 • Replaces Claude Sonnet</div>
      <div style={{ fontWeight: 700, marginBottom: 6 }}>System Prompt Node</div>
      <div style={{ fontSize: 11, background: '#0a0a0a', padding: 8, borderRadius: 8, whiteSpace: 'pre-wrap' }}>{(data as any).prompt?.slice(0,120)}...</div>
      <div style={{ marginTop: 6, fontSize: 10, color: '#666' }}>This is your IP / Moat</div>
      <Handle type="source" position={Position.Right} />
    </div>
  )
}
