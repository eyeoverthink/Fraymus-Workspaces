import { Handle, Position, NodeProps } from '@xyflow/react'

export function FluxNode({ data, selected }: NodeProps) {
  return (
    <div style={{ width: 280, background: selected ? '#1a1a1a' : '#111', border: `1px solid ${selected ? '#fff' : '#333'}`, borderRadius: 12, padding: 12 }}>
      <div style={{ fontSize: 11, color: '#888', marginBottom: 8 }}>FREE • FLUX.1 [schnell] • Replaces Nano Banana</div>
      <div style={{ fontWeight: 700, marginBottom: 6 }}>FLUX Generator</div>
      <div style={{ fontSize: 12, color: '#aaa' }}>Model: {(data as any).model}</div>
      <div style={{ marginTop: 8, background: '#0a0a0a', padding: 8, borderRadius: 8, fontSize: 11 }}>
        prompt → image<br/>cost: FREE Apache 2.0
      </div>
      <Handle type="target" position={Position.Left} />
      <Handle type="source" position={Position.Right} />
    </div>
  )
}
