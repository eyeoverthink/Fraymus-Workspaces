import { ReactFlow, Background, Controls, useNodesState, useEdgesState, addEdge } from '@xyflow/react'
import { useCallback, useEffect } from 'react'
import { nodeTypes } from '../nodes'
import { useWorkflowStore } from '../store/useWorkflowStore'

export default function WorkflowCanvas() {
  const { nodes: initialNodes, edges: initialEdges, setNodes: storeSetNodes, setEdges: storeSetEdges } = useWorkflowStore()
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  // Sync to store + REA
  useEffect(() => { storeSetNodes(nodes as any) }, [nodes])
  useEffect(() => { storeSetEdges(edges as any) }, [edges])

  // Send to REA on change for realtime suggestions
  useEffect(() => {
    fetch('/api/rea/suggest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nodes, edges }) }).catch(()=>{})
  }, [nodes, edges])

  const onConnect = useCallback((params: any) => setEdges((eds) => addEdge(params, eds)), [setEdges])

  return (
    <div style={{ width: '100%', height: '100%', background: '#0a0a0a' }}>
      <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes as any} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect} fitView>
        <Background color="#222" gap={16} />
        <Controls />
      </ReactFlow>
    </div>
  )
}
