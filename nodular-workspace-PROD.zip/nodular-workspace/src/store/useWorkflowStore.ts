import { create } from 'zustand'
import { Node, Edge } from '@xyflow/react'

type WorkflowState = {
  nodes: Node[]
  edges: Edge[]
  code: string
  previewHtml: string
  agentSuggestion: string
  setNodes: (n: Node[]) => void
  setEdges: (e: Edge[]) => void
  setCode: (c: string) => void
}

export const useWorkflowStore = create<WorkflowState>((set) => ({
  nodes: [
    { id: '1', type: 'llama', position: { x: 50, y: 80 }, data: { prompt: 'A mirror selfie of a woman in vintage denim, UGC style' } },
    { id: '2', type: 'flux', position: { x: 380, y: 120 }, data: { model: 'black-forest-labs/FLUX.1-schnell', steps: 4 } },
    { id: '3', type: 'htmlPreview', position: { x: 720, y: 80 }, data: { html: '<div style="padding:20px">Output will appear here</div>' } },
  ],
  edges: [{ id: 'e1-2', source: '1', target: '2' }, { id: 'e2-3', source: '2', target: '3' }],
  code: '// Node executor code will appear here\n// REA will patch in realtime',
  previewHtml: '<div style="padding:24px;color:#888">Run workflow to see result</div>',
  agentSuggestion: '💡 REA: Add a Background Remover node after FLUX for clean UGC?',
  setNodes: (nodes) => set({ nodes }),
  setEdges: (edges) => set({ edges }),
  setCode: (code) => set({ code }),
}))
