import WorkflowCanvas from './canvas/WorkflowCanvas'
import MonacoWorkspace from './editor/MonacoWorkspace'
import LivePreview from './editor/LivePreview'

export default function App() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr 0.6fr', gridTemplateRows: '100vh', background: '#0a0a0a' }}>
      <div style={{ borderRight: '1px solid #222', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid #222', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div><div style={{ fontWeight: 800, letterSpacing: -0.5 }}>NODULAR</div><div style={{ fontSize: 10, color: '#888' }}>WORKSPACE v0.1 • FREE 2026 STACK • Wrapper → Workflow</div></div>
          <div style={{ fontSize: 10, background: '#1a1a1a', padding: '4px 8px', borderRadius: 20, border: '1px solid #333' }}>● REA Live • Socket.io + Yjs</div>
        </div>
        <div style={{ flex: 1 }}><WorkflowCanvas /></div>
      </div>
      <MonacoWorkspace />
      <LivePreview />
    </div>
  )
}
