// FREE 2026 API REGISTRY - replace Nano Banana etc
export const FREE_REGISTRY = {
  'flux-schnell': {
    name: 'FLUX.1 [schnell] Free',
    provider: 'HuggingFace Inference',
    endpoint: 'https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell',
    cost: 'FREE - Apache 2.0',
    inputs: [{ name: 'prompt', type: 'string', required: true }, { name: 'seed', type: 'number', required: false }],
    outputs: [{ name: 'image', type: 'image' }],
    docs: 'HF Inference free tier, 4 steps, fastest open model'
  },
  'sdxl-lightning': {
    name: 'SDXL Lightning Free',
    provider: 'HF / Fal.ai free credits',
    endpoint: 'ByteDance/SDXL-Lightning',
    cost: 'FREE',
    inputs: [{ name: 'prompt', type: 'string' }],
    outputs: [{ name: 'image', type: 'image' }]
  },
  'llama-groq': {
    name: 'Llama 3.3 70B Free',
    provider: 'Groq',
    endpoint: 'https://api.groq.com/openai/v1/chat/completions',
    cost: 'FREE 14k tok/s',
    inputs: [{ name: 'prompt', type: 'string' }],
    outputs: [{ name: 'text', type: 'string' }],
    note: 'Replaces Claude Sonnet as brain'
  },
  'wan-animate': {
    name: 'Wan 2.1 Animate Free',
    provider: 'Replicate free tier',
    endpoint: 'replicate/wan-video/wan-2.1',
    cost: 'FREE credits',
    note: 'Replaces Kora Reality'
  }
}

export type NodeSpec = typeof FREE_REGISTRY[keyof typeof FREE_REGISTRY]
