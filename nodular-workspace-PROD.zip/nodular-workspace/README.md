# NODULAR WORKSPACE SYSTEM // FREE 2026 STACK

Rebuild of the $4M Enhancor Workflows video using 100% free tools.

## Core Pattern from Video
Wrapper (1 API) -> Dies. Workflow (chain + system prompt + logic) -> IP.

This repo implements:
- ReactFlow canvas (nodular editor)
- Monaco code editor + Live HTML preview
- Node.js DAG executor
- FREE replacements: FLUX.1 schnell (HF) replaces Nano Banana 2, Groq Llama replaces Claude Sonnet, Wan 2.1 replaces Kora Reality
- REA: Real-time Editing Agent that suggests next nodes live via Socket.io + Yjs

## Run
npm i
# set .env from .env.example
npm run dev:all
- Canvas: http://localhost:5173
- Server: http://localhost:3001

## Video Concepts Implemented
- API -> Node conversion via registry.ts
- Canvas editor from scratch (WorkflowCanvas.tsx)
- System prompt as moat (LlamaNode)
- Deployable endpoint (HtmlPreviewNode + executor)

## REA Flow
User drags node -> canvas JSON -> POST /api/rea/suggest -> Socket.io broadcast -> Monaco ghost text + suggestion chip

Add your own free models in src/engine/registry.ts
