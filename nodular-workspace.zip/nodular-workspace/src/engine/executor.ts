import { FREE_REGISTRY } from './registry'

// Simple DAG executor - runs nodes in topological order
export async function executeWorkflow(nodes: any[], edges: any[], env: Record<string,string>) {
  const outputs: Record<string, any> = {}
  const sorted = topologicalSort(nodes, edges)
  
  for (const nodeId of sorted) {
    const node = nodes.find(n => n.id === nodeId)
    if (!node) continue
    
    // FREE EXECUTION LOGIC
    if (node.type === 'llama') {
      // Call Groq free
      const res = await fetch('/api/llama', { method: 'POST', body: JSON.stringify({ prompt: node.data.prompt }) })
      outputs[nodeId] = await res.json()
    }
    if (node.type === 'flux') {
      // Call HF free FLUX
      const prompt = outputs[edges.find(e=>e.target===nodeId)?.source]?.text || node.data.prompt
      const res = await fetch('/api/flux', { method: 'POST', body: JSON.stringify({ prompt, model: node.data.model }) })
      const blob = await res.blob()
      outputs[nodeId] = { imageUrl: URL.createObjectURL(blob) }
    }
  }
  return outputs
}

function topologicalSort(nodes: any[], edges: any[]) {
  // naive - assumes linear for MVP
  const inDegree: Record<string, number> = {}
  nodes.forEach(n => inDegree[n.id] = 0)
  edges.forEach(e => inDegree[e.target]++)
  const q = nodes.filter(n => inDegree[n.id]===0).map(n=>n.id)
  const out = []
  while(q.length){ const id=q.shift()!; out.push(id); edges.filter(e=>e.source===id).forEach(e=>{ inDegree[e.target]--; if(inDegree[e.target]===0) q.push(e.target) }) }
  return out
}
