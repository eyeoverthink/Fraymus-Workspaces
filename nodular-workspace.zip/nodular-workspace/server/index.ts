import Fastify from 'fastify'
import { Server } from 'socket.io'

const fastify = Fastify({ logger: true })

// --- FREE API PROXIES ---

// 1. Groq Free Llama - replaces Claude Sonnet as brain
fastify.post('/api/llama', async (req, reply) => {
  const { prompt } = req.body as any
  const GROQ_KEY = process.env.GROQ_API_KEY // free tier
  const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${GROQ_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'llama-3.3-70b-versatile', messages: [{ role: 'user', content: prompt }], max_tokens: 512 })
  })
  const data = await r.json()
  return { text: data.choices?.[0]?.message?.content, raw: data }
})

// 2. HF FLUX.1 schnell Free - replaces Nano Banana 2
fastify.post('/api/flux', async (req, reply) => {
  const { prompt } = req.body as any
  const HF_KEY = process.env.HF_TOKEN // free read token
  const r = await fetch('https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${HF_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ inputs: prompt, parameters: { num_inference_steps: 4 } })
  })
  const buf = await r.arrayBuffer()
  reply.header('Content-Type', 'image/png').send(Buffer.from(buf))
})

// 3. REA - Realtime Editing Agent
fastify.post('/api/rea/suggest', async (req, reply) => {
  const { nodes, edges } = req.body as any
  // Simple heuristic MVP - in production call Groq here
  let suggestion = '💡 REA: Your Llama → FLUX chain looks good. Add Upscaler node for 4K product shots?'
  if (nodes.length === 1) suggestion = '💡 REA: Add FLUX [schnell] node - its Apache 2.0 free and 4 steps vs Nano Banana'
  if (nodes.some((n:any)=>n.type==='flux') && !nodes.some((n:any)=>n.type==='htmlPreview')) suggestion = '💡 REA: Add HTML Preview to deploy as API endpoint - thats the product moat'
  
  // Broadcast via Socket.io to all clients (realtime)
  // @ts-ignore
  fastify.io?.emit('rea:suggestion', { suggestion, nodes })
  return { suggestion }
})

await fastify.listen({ port: 3001 })
const io = new Server(fastify.server, { cors: { origin: '*' } })
// @ts-ignore
fastify.io = io

io.on('connection', (socket) => {
  console.log('REA client connected', socket.id)
  socket.on('canvas:update', (data) => socket.broadcast.emit('canvas:update', data))
})

console.log('Nodular server + REA running on :3001 - FREE STACK')
